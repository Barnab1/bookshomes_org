let citations = [
    {
        citation:"L'Homme n'est grand qu'à genoux",
        auteur:"Victor Hugo",
        color:"red"
    }, 
    {
        citation:"La vie est un mystère qu'il faut  vivre, et non un problème à résoudre",
        auteur:"Gandhi",
        color:"white"
    },
    {
        citation:"Vous pouvez obtenir tout ce que vous désirez dans la vie si vous aidez suffisamment de personnes à obtenir ce qu'elles veulent",
        auteur:"Zig Ziglar",
        color:"green"
    },
    {
        citation:"L'inspiration existe, mais il faut qu'elle vous trouve au travail",
        auteur:"Pablo Picasso",
        color:"purle"
    },
    {
        citation:"Ne vous contentez pas du statu quo. Donnez votre meilleur sur le moment. Ensuite que cela réussise ou échoue, vous aurez au moins tout donné",
        auteur:"Angella Basset",
        color:"red"
    },
    {
        citation:"Montrez-vous, montrez-vous, montrez-vous, et au bout d'un moment la muse se montrera également",
        auteur:"Isabel Allende",
        color:"yellow"
    },
    {
        citation:"Celui qui se perd dans sa passion a moins perdu que celui qui perd sa passion",
        auteur:"Alexandre Jardin"
    },
    {
        citation:"Si vous voulez que la vie vous sourie, apportez-lui d'abord votre bonne humeur",
        auteur:"Baruch Spinoza"
    },
    {
        citation:"Amour et charité appellent Dieu",
        auteur:"Saint François d'Assise"
    },
    {
        citation:"Oubliez l'inspiration à un stade initial. les habitudes sont plus fiables.Les habitudes vous permettront de terminer et de peaufiner vos histoires. les habitudes représentent la persistance mise en pratique",
        auteur:"Octavia Butler"
    },
    {
        citation:"Le courage est comme un muscle, on le renforce en le travaillant",
        auteur:"Ruth Gordo"
    },
    {
        citation:"Contruisez votre succès à partir de vos échecs. le découragement et l'échec sont les étapes les plus sûres pour parvenir au succès",
        auteur:"Dale Carnegie"
    },
    {
        citation:"Le seul moyen de découvrir les limites du possible est de s'aventurer un peu plus loin dans l'impossible",
        auteur:"Arthur C. Clarke"
    },
    {
        citation:"Ne laissez pas le bruit des autres masquer votre voie intérieure",
        auteur:"Steve Jobs"
    }
];