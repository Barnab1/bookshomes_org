<?php echo $jean ?? ''?>
    <div class="squeeze-container">
        <div class="squeeze-header"></div>
        <h1 class="squeeze-title text_center">
            N'as-tu jamais eu le désir de mettre
            quelque chose en ligne pour tes amis ?
        </h1>
        <p class="squeeze-text text_center">
            Si oui n'attend plus pour commencer à coder aujourd'hui 
            avec moi. <span class="bold"> Sois sans crainte, j'ai été aussi un débutant.</span>

        </p>
        <form action="/squeeze/developper" method="POST" class="squeeze-form">
            <input type="email" name="" id="" placeholder="Entre une email valide ici">
            <button type="submit">Commence à coder dès aujourd'hui</button>
        </form>
        <p class="security-insurance text_center">
            N'aies nulle crainte, ton contact est en parfaite sécurité. La preuve est que 
            je le recevrai moi-même tout à l'heure et <span class="bold"> je t'enverrai par email le document pour débuter.</span> 
        </p>

