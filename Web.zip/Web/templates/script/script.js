/**
 * Main Javascript File
 */


/**
 * Toggle Button
 * START
 */

/*
let toggleMenu = document.getElementById('toggleMenu');
let toggleButton = document.getElementById('toggleButton');


    toggleButton.addEventListener("click",(e)=>{
        toggleButton.classList.toggle("on");
        toggleMenu.classList.toggle("on");
        
        
    });
*/

/**
 * Toggle Button
 * END
 */


/**
 * Links about Books field
 * START
 */


/**
 * Links about Books field
 * END
 */